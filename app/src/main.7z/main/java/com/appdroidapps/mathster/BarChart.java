package com.appdroidapps.mathster;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by PanKaj on 1/10/2016.
 */
public class BarChart extends LinearLayout {
    private final Context context;
    private int total_height;
private int[] colors = new int[]{Color.parseColor("#794044"),Color.parseColor("#114355"),Color.parseColor("#009f6a"),Color.parseColor("#ab9c73"),Color.parseColor("#daa520"),Color.parseColor("#31698a"),Color.parseColor("#d4383a"),Color.parseColor("#794044"),Color.parseColor("#794044"),Color.parseColor("#114355"),Color.parseColor("#009f6a"),Color.parseColor("#ab9c73"),Color.parseColor("#daa520"),Color.parseColor("#31698a"),Color.parseColor("#d4383a"),Color.parseColor("#794044"),Color.parseColor("#794044"),Color.parseColor("#114355"),Color.parseColor("#009f6a"),Color.parseColor("#ab9c73"),Color.parseColor("#daa520"),Color.parseColor("#31698a"),Color.parseColor("#d4383a"),Color.parseColor("#794044"),Color.parseColor("#794044"),Color.parseColor("#114355"),Color.parseColor("#009f6a"),Color.parseColor("#ab9c73"),Color.parseColor("#daa520"),Color.parseColor("#31698a"),Color.parseColor("#d4383a"),Color.parseColor("#794044")};

    private boolean init;
    private ArrayList<BarData> bars_list;
    private int biggest_point;

    public BarChart(Context context) {
        super(context);
        this.context = context;
        init();
    }

    public BarChart(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        init();
    }

    public BarChart(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context = context;
        init();
    }

    public BarChart(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr);
        this.context = context;
        init();
    }

    private void init() {
        this.setOrientation(LinearLayout.HORIZONTAL);
        this.removeAllViews();
if(bars_list == null)
{
    bars_list = new ArrayList<BarData>();
}
        biggest_point = 0;
        // find biggest value
        for(int i=0;i< bars_list.size();i++)
        {
            int point = bars_list.get(i).getPoint();
            if(biggest_point<point)
            {
                biggest_point = point;
            }

        }
        initViews();
    }

    private void initViews() {
        for(int i=0;i<bars_list.size();i++)
        {
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT,1.0f);

            layoutParams.setMargins(5, 5, 5, 5);

            LinearLayout parent_layout = new LinearLayout(context);
            parent_layout.setLayoutParams(layoutParams);
            parent_layout.setOrientation(LinearLayout.VERTICAL);

          //  parent_layout.setPadding(5, 5, 5, 5);
            parent_layout.setGravity(Gravity.BOTTOM);
            addView(parent_layout, i);

        }
        this.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_bar_one));
        this.post(new Runnable() {
            @Override
            public void run() {
                total_height = getHeight();
                Log.i("Parent", "height=" + total_height);
                if (total_height != 0) {
                    if (!init) {
                        initChildViews();
                        init = true;
                    }
                }
            }
        });
    }

    private void initChildViews() {
        // gap on top REQUIRED
        biggest_point = biggest_point+20;

        Log.i("Parent", "initChildViews=" + this.getChildCount());
        for(int i=0;i< bars_list.size();i++) {
            LinearLayout parent_layout = (LinearLayout)getChildAt(i);
            BarData bar_info = bars_list.get(i);
            float child_percent = (bar_info.getPoint() * 100.0f) / biggest_point;
            int child_height = (int)((total_height / 100.0f)* child_percent);
            Log.i("Child","child_height = "+child_height);
            LinearLayout.LayoutParams child_view_lparams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
            LinearLayout child_view = new LinearLayout(context);
            child_view.setLayoutParams(child_view_lparams);
            child_view.setOrientation(LinearLayout.VERTICAL);
            TextView text_view = new TextView(context);
            text_view.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            text_view.setText(String.valueOf(bar_info.getPoint()));
            text_view.setSingleLine(true);
            text_view.setGravity(Gravity.CENTER);
            text_view.setTypeface(Typeface.DEFAULT_BOLD);
            text_view.setTextSize(18);
            text_view.setPadding(2, 2, 2, 2);
            text_view.setTextColor(colors[i]);
            text_view.setEllipsize(TextUtils.TruncateAt.END);
            text_view.setShadowLayer(1, 0, 0, Color.BLACK);
            View view = new View(context);

            ViewGroup.LayoutParams view_layoutparams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,child_height);
            view.setLayoutParams(view_layoutparams);
            view.setBackgroundColor(colors[i]);


            TextView label_view = new TextView(context);
            label_view.setText(bar_info.getLabel());
            label_view.setGravity(Gravity.CENTER);
            label_view.setSingleLine(true);
            label_view.setShadowLayer(1, 0, 0, Color.BLACK);
            label_view.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            label_view.setEllipsize(TextUtils.TruncateAt.END);

            child_view.addView(text_view);
            child_view.addView(view);
            child_view.addView(label_view);

            parent_layout.addView(child_view);
        }

    }



    public void setBarData(ArrayList<BarData> data_list) {
this.bars_list = data_list;
        init();
    }
}
