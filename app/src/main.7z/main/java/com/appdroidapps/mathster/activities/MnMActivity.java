package com.appdroidapps.mathster.activities;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import com.appdroidapps.mathster.R;
import com.appdroidapps.mathster.query.QueryInterface;

import java.util.HashMap;

/**
 * Created by pranay on 14/11/15.
 */

public class MnMActivity extends PlayFieldActivity {


    private static Runnable r = null;

    private int progress;
    private AlertDialog builder;

    //  MediaPlayer mediaPlayer;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        //     mediaPlayer = MediaPlayer.create(this, R.raw.beep);
    }

    public void onRightAnswer() {
        if (progress > 66) {
            bonustextSwitcher.setText("+3 XP");
            rightAnswerCount = rightAnswerCount + 3;
        } else if (progress > 33) {
            bonustextSwitcher.setText("+2 XP");
            rightAnswerCount = rightAnswerCount + 2;
        } else {
            bonustextSwitcher.setText("");
        }
        vibrator.vibrate(25);
        refresh();
        next();

    }

    public void onWrongAnswer() {
        refresh();
        vibrator.vibrate(500);
        showScore(GAME_OVER_REASON.WRONG_ANSWER);
    }

    public void onTimeOut() {
        refresh();
        vibrator.vibrate(500);
        showScore(GAME_OVER_REASON.TIMEOUT);
    }


    private void next() {
        textSwitcher.setText("" + rightAnswerCount);
        showQuestion(QueryInterface.getQuestion(QueryInterface.MODES.MAKE_NO_MISTAKE, this));

        final long startTime = System.currentTimeMillis();

        synchronized (this) {
            r = new Runnable() {
                int counter = 0;

                public void run() {
                    counter++;
                    long timeElapsed = System.currentTimeMillis() - startTime;

                    if (timeElapsed < 5000) {
                        int modulo = 10;
                        if (timeElapsed > 4000) {
                            modulo = 2;
                        } else if (timeElapsed > 3000) {
                            modulo = 5;
                        } else if (timeElapsed > 2000) {
                            modulo = 8;
                        }
                        if (counter % modulo == 0) {
                            //             mediaPlayer.start();
                        }
                        int timeInSecs = (int) (5000 - timeElapsed);
                        progress = 100 * timeInSecs / 5000;
                        progressBar.setProgress(progress);
                        handler.postDelayed(this, 50);
                    } else {
                        onTimeOut();
                    }
                }
            };
            r.run();
        }
    }

    public void refresh() {
        if (r != null) {
            handler.removeCallbacks(r);
        }
        if (builder != null && builder.isShowing()) {
            builder.dismiss();
        }
    }

    void showScore(GAME_OVER_REASON reason) {

        loadBanner();
        int topScore = getMnMTopScore();
        String title = "Score";
        String text = "Your score : " + rightAnswerCount + "";
        switch (reason) {
            case TIMEOUT:
                title = "Oops ! Timed out";
                break;
            case WRONG_ANSWER:
                title = "Nah ! That's wrong";
                break;
        }


        HashMap<String, Object> profileProps = new HashMap<String, Object>();
        if (rightAnswerCount > topScore) {
            setMnMTopScore(rightAnswerCount);
            if (topScore != -1) {
                title = "Congratulations!";
                text = "You've beat your previous score of " + topScore;
            }
            profileProps.put("High Score", rightAnswerCount);
        }
        setHistogramValues(rightAnswerCount);
        profileProps.put("Last Score", topScore);
        cleverTapAPI.profile.push(profileProps);

        HashMap<String, Object> gameEndedProperties = new HashMap<String, Object>();
        gameEndedProperties.put("Score", rightAnswerCount);
        cleverTapAPI.event.push("Game Ended", gameEndedProperties);
        LayoutInflater inflater = getLayoutInflater();
        View dialoglayout = inflater.inflate(R.layout.dialog_layout, null);
        TextView titletextView = (TextView) dialoglayout.findViewById(R.id.titletextView);
        TextView content_textView = (TextView) dialoglayout.findViewById(R.id.content_textView);
        Button back_button = (Button) dialoglayout.findViewById(R.id.back_button);
        Button try_button = (Button) dialoglayout.findViewById(R.id.try_button);
        titletextView.setText(title);
        content_textView.setText(text);
        AlertDialog.Builder bd = new AlertDialog.Builder(this)
                .setView(dialoglayout);
         builder = bd.create();
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (builder != null) {
                    builder.dismiss();
                }
                onBackPressed();
            }
        });
        try_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //      mGoogleApiClient.connect();
                //      Games.Leaderboards.submitScore(mGoogleApiClient, "CgkI6piK5YoSEAIQAA", 10);

                cleverTapAPI.event.push("RePlayed");
                HashMap<String, Object> profileProps = new HashMap<String, Object>();
                profileProps.put("Replayed", "true");
                cleverTapAPI.profile.push(profileProps);

                refresh();
                Intent intent = getIntent();
                intent.putExtra("replayed", true);
                finish();
                startActivity(intent);
            }
        });

        refresh();
     builder.show();

    }

    @Override
    protected void onPause() {
        super.onPause();
        refresh();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        refresh();
    }

    @Override
    protected void onStop() {
        super.onStop();
        refresh();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        refresh();

    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        QueryInterface.refresh();
        next();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

    }
}
