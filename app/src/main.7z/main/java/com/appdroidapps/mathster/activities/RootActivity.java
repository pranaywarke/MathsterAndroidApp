package com.appdroidapps.mathster.activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.clevertap.android.sdk.CleverTapAPI;
import com.clevertap.android.sdk.exceptions.CleverTapMetaDataNotFoundException;
import com.clevertap.android.sdk.exceptions.CleverTapPermissionsNotSatisfied;

/**
 * Created by pranay on 14/11/15.
 */
public class RootActivity extends AppCompatActivity {


    protected static final boolean SHOW_ADS = true;
    private static final String SUFFIX = "2";
    private static final String MNM_KEY = "score" + SUFFIX;
    private static final String LAST_UPDATED_LEADERBOARD_SCORE = "last_up_score" + SUFFIX;
    private static final String LEADERBOARD_SYNC = "l_sync" + SUFFIX;
    protected static SharedPreferences sharedPreferences;
    protected static SharedPreferences.Editor editor;

    private static final String HISTOGRAM_PREFIX_STR = "Histogram_" + SUFFIX;
    public static CleverTapAPI cleverTapAPI;


    enum HistogramBuckets {

        bucket1("< 50", 0, 50),
        bucket2("51 - 100", 50, 100),
        bucket3("101 - 200", 101, 200),
        bucket4("201 - 300", 201, 300),
        bucket5("301 - 400", 301, 400),
        bucket6("401 - 500", 401, 500),
        bucket7("501 - 600", 501, 600),
        bucket8("600 >", 600, 100000);

        HistogramBuckets(String label, int min, int max) {
            this.label = label;
            this.max = max;
            this.min = min;
        }

        String label;
        int min, max;
        private static HistogramBuckets[] vals = values();

        public static HistogramBuckets getBucket(long score) {
            if (score == 0) return null; // not storing 0 scores
            if (score < 50) return bucket1;
            if (score > 600) return bucket8;
            for (int i = 0; i < vals.length - 1; i++) {

                if (score >= vals[i].min && score < vals[i].max) {
                    return vals[i];
                }
            }
            return null;
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        synchronized (this) {
            if (sharedPreferences == null) {
                sharedPreferences = getSharedPreferences("com.appdroidapps.mathster", Context.MODE_PRIVATE);
                editor = sharedPreferences.edit();
            }
            if (cleverTapAPI == null) {
                try {
                    cleverTapAPI = CleverTapAPI.getInstance(this);
                } catch (CleverTapMetaDataNotFoundException e) {
                    e.printStackTrace();
                } catch (CleverTapPermissionsNotSatisfied cleverTapPermissionsNotSatisfied) {
                    cleverTapPermissionsNotSatisfied.printStackTrace();
                }
            }

        }


    }

    public static int getMnMTopScore() {
        return (int) sharedPreferences.getLong(MNM_KEY, -1);
    }

    public static void setMnMTopScore(long score) {
        editor.putLong(MNM_KEY, (long) score);
        editor.commit();
    }

    public static void setHistogramValues(long score) {

        HistogramBuckets b = HistogramBuckets.getBucket(score);
        if (b != null) {
            int prev = sharedPreferences.getInt(HISTOGRAM_PREFIX_STR + b.ordinal(), 0);
            prev++;
            editor.putInt(HISTOGRAM_PREFIX_STR + b.ordinal(), prev);
            editor.commit();
        }
    }

    public static void clearHistogramValues() {
        for (HistogramBuckets b : HistogramBuckets.vals) {
            editor.putInt(HISTOGRAM_PREFIX_STR + b.ordinal(), 0);
        }
        editor.commit();
    }


    public static int[] getHistogramValues() {
        int[] r = new int[HistogramBuckets.vals.length];
        for (HistogramBuckets b : HistogramBuckets.vals) {
            int v = sharedPreferences.getInt(HISTOGRAM_PREFIX_STR + b.ordinal(), 0);
            r[b.ordinal()] = v;
        }
        return r;
    }

    public static int getLeaderBoardLastUpdatedTopScore() {
        return (int) sharedPreferences.getLong(LAST_UPDATED_LEADERBOARD_SCORE, -1);
    }

    public static void setLeaderBoardLastUpdatedTopScore(long score) {

        editor.putLong(LAST_UPDATED_LEADERBOARD_SCORE, score);
        editor.commit();
    }

    public static boolean isLeaderBoardSynced() {
        return sharedPreferences.getBoolean(LEADERBOARD_SYNC, false);
    }

    public static void setLeaderBoardSynced(boolean sync) {

        editor.putBoolean(LEADERBOARD_SYNC, sync);
        editor.commit();
    }

    protected boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

}