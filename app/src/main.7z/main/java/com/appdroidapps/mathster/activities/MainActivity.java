package com.appdroidapps.mathster.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.appdroidapps.mathster.BarChart;
import com.appdroidapps.mathster.BarData;
import com.appdroidapps.mathster.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by pranay on 02/11/15.
 */
public class MainActivity extends RootActivity {

    TextView mnm, mi;
    TextView highScore, highScoreLabel;
    private Button go_button;
    private Button viewlb_button;

    protected InterstitialAd mInterstitialAd;
    private BarChart histogram;


    protected void requestNewInterstitial() {
        if (mInterstitialAd != null) {
            AdRequest adRequest = new AdRequest.Builder()
                    .addTestDevice("3BF3563231EC0E15536D1F94441DBD55")
                    .build();

            mInterstitialAd.loadAd(adRequest);
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity_new);
        mnm = (TextView) findViewById(R.id.mnm);
        highScore = (TextView) findViewById(R.id.topScore);
        highScoreLabel = (TextView) findViewById(R.id.highScoreLabel);
        go_button = (Button) findViewById(R.id.go_button);
        viewlb_button = (Button) findViewById(R.id.viewlb_button);

        if (SHOW_ADS) {
            mInterstitialAd = new InterstitialAd(this);
            mInterstitialAd.setAdUnitId("ca-app-pub-2882064284132215/5034737489");
            mInterstitialAd.setAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    super.onAdClosed();
                    requestNewInterstitial();
                }
            });
            requestNewInterstitial();
        }

        viewlb_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cleverTapAPI.event.push("LeaderBoard Clicked");
                Intent in = new Intent(MainActivity.this, ScoreActivity.class);
                in.setAction(ScoreActivity.ACTION_VIEW_LEADERBOARD);
                startActivity(in);

            }
        });
       /* String version_name = "1.0";
        try {
            PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            version_name = pInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        version.setText("Mathster v" + version_name);*/

        go_button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                cleverTapAPI.event.push("Go Started");
                Intent intent = new Intent(MainActivity.this, MnMActivity.class);
                startActivity(intent);
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();
        int ts = RootActivity.getMnMTopScore();
        int[] histo = RootActivity.getHistogramValues();
        Log.i("Histo","histo= "+histo.length);
       
        if (histo != null) {
            if(histogram == null) {
                histogram = (BarChart) findViewById(R.id.bar_view);
                ArrayList<BarData> data_list = new ArrayList<BarData>();
                data_list.add(new BarData("<50", histo[0]));
                data_list.add(new BarData("50-100", histo[1]));
                data_list.add(new BarData("100-200", histo[2]));
                data_list.add(new BarData("200-300", histo[3]));
                data_list.add(new BarData("300-400", histo[4]));
                data_list.add(new BarData("400-500", histo[5]));
                data_list.add(new BarData("500-600", histo[6]));
                data_list.add(new BarData("600-700", histo[7]));
                histogram.setBarData(data_list);
            }
        }
        if (ts != -1) {
            highScore.setLines(2);
            highScore.setGravity(Gravity.CENTER);
            highScore.setText(ts + "");
            highScore.setVisibility(View.VISIBLE);
           histogram.setVisibility(View.VISIBLE);
            highScoreLabel.setVisibility(View.VISIBLE);
        } else {
            highScore.setVisibility(View.INVISIBLE);
            histogram.setVisibility(View.INVISIBLE);
            highScoreLabel.setVisibility(View.INVISIBLE);
        }
    }
}
