package com.appdroidapps.mathster;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;

public class TestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        BarChart bar_view = (BarChart)findViewById(R.id.bar_view);
        ArrayList<BarData> data_list = new ArrayList<BarData>();
        data_list.add(new BarData("<50",40));
        data_list.add(new BarData("50-100",7));
        data_list.add(new BarData("100-200",45));
        data_list.add(new BarData("200-300",100));
        data_list.add(new BarData("300-400",65));
        data_list.add(new BarData("100-200",45));
        data_list.add(new BarData("200-300",100));
        data_list.add(new BarData("300-400",65));
        bar_view.setBarData(data_list);
    }
}
